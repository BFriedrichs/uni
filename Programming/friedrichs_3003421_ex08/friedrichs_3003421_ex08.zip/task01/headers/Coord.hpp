#ifndef COORD_H
#define COORD_H

struct Coord {
  int row;
  int col;
};

#endif
