/* scope2.c */
float globalvar;
void modtest(void) {
 globalvar = 2;
}