void resetCalculator();
int parseInput();
int calcResult();
int inArray(char *needle, char *haystack);