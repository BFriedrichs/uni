
Use make to produce boot.bin or compile bootsector.c and execute it yourself.